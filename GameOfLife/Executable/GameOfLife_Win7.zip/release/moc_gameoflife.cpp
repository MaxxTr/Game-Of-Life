/****************************************************************************
** Meta object code from reading C++ file 'gameoflife.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../src/Headers/gameoflife.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'gameoflife.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_GameOfLife_t {
    QByteArrayData data[18];
    char stringdata[242];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_GameOfLife_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_GameOfLife_t qt_meta_stringdata_GameOfLife = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 12),
QT_MOC_LITERAL(2, 24, 0),
QT_MOC_LITERAL(3, 25, 3),
QT_MOC_LITERAL(4, 29, 12),
QT_MOC_LITERAL(5, 42, 12),
QT_MOC_LITERAL(6, 55, 11),
QT_MOC_LITERAL(7, 67, 12),
QT_MOC_LITERAL(8, 80, 11),
QT_MOC_LITERAL(9, 92, 11),
QT_MOC_LITERAL(10, 104, 11),
QT_MOC_LITERAL(11, 116, 20),
QT_MOC_LITERAL(12, 137, 19),
QT_MOC_LITERAL(13, 157, 26),
QT_MOC_LITERAL(14, 184, 22),
QT_MOC_LITERAL(15, 207, 11),
QT_MOC_LITERAL(16, 219, 8),
QT_MOC_LITERAL(17, 228, 12)
    },
    "GameOfLife\0widthChanged\0\0val\0hightChanged\0"
    "startClicked\0nextClicked\0pauseClicked\0"
    "stopClicked\0zoomChanged\0infoClicked\0"
    "setGlobalInformation\0setGroupInformation\0"
    "setBestPredatorInformation\0"
    "setBestPreyInformation\0helpClicked\0"
    "nextLoop\0updateInfoUI\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_GameOfLife[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x0a,
       4,    1,   92,    2, 0x0a,
       5,    0,   95,    2, 0x0a,
       6,    0,   96,    2, 0x0a,
       7,    0,   97,    2, 0x0a,
       8,    0,   98,    2, 0x0a,
       9,    1,   99,    2, 0x0a,
      10,    0,  102,    2, 0x0a,
      11,    0,  103,    2, 0x0a,
      12,    0,  104,    2, 0x0a,
      13,    0,  105,    2, 0x0a,
      14,    0,  106,    2, 0x0a,
      15,    0,  107,    2, 0x0a,
      16,    0,  108,    2, 0x09,
      17,    0,  109,    2, 0x09,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void GameOfLife::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        GameOfLife *_t = static_cast<GameOfLife *>(_o);
        switch (_id) {
        case 0: _t->widthChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->hightChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->startClicked(); break;
        case 3: _t->nextClicked(); break;
        case 4: _t->pauseClicked(); break;
        case 5: _t->stopClicked(); break;
        case 6: _t->zoomChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->infoClicked(); break;
        case 8: _t->setGlobalInformation(); break;
        case 9: _t->setGroupInformation(); break;
        case 10: _t->setBestPredatorInformation(); break;
        case 11: _t->setBestPreyInformation(); break;
        case 12: _t->helpClicked(); break;
        case 13: _t->nextLoop(); break;
        case 14: _t->updateInfoUI(); break;
        default: ;
        }
    }
}

const QMetaObject GameOfLife::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_GameOfLife.data,
      qt_meta_data_GameOfLife,  qt_static_metacall, 0, 0}
};


const QMetaObject *GameOfLife::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *GameOfLife::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_GameOfLife.stringdata))
        return static_cast<void*>(const_cast< GameOfLife*>(this));
    return QWidget::qt_metacast(_clname);
}

int GameOfLife::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
